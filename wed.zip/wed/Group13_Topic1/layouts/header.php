<!DOCTYPE html>
<html>
<head>
	<title><?=$title?></title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

	<link ref="stylesheet" href="styles.css">
<body>
	<!-- header START -->
	<!-- Grey with black text -->
	<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
	  <div class="container" style="padding: 0px !important;">
	  	<ul class="navbar-nav">
		    <li class="nav-item active">
		      <a class="nav-link" href="index.php">Trang chủ</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="index.php">Cửa Hàng</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="index.php">Giới Thiệu</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="index.php">Lịch sử giao dịch</a>
		    </li>
		    <li class="nav-item">
		      <a class="nav-link" href="https://www.facebook.com/">Liên hệ</a>
		    </li>
		  </ul>
<?php
$cart = [];
if(isset($_SESSION['cart'])) {
	$cart = $_SESSION['cart'];
}
$count = 0;
foreach ($cart as $item) {
	$count += $item['num'];
}
?>
			<a href="cart.php">
				<button type="button" class="btn btn-primary">
					Giỏ Hàng <span class="badge badge-light"><?=$count?></span>
				</button>
			</a>
	  </div>
	</nav>
	<!-- header END -->

	<div class="container main">