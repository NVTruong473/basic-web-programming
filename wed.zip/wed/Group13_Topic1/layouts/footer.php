	</div>
	<!-- Footer -->
	<footer style="background-color: black; color: white; padding: 10px;">
	<address>
					  <strong>    SHOP thời trang BinhTruongCuong</strong><br>
					  <span class="glyphicon glyphicon-home" aria-hidden="true"></span> Địa chỉ: Tân Phong - Quận 7 - Thành phố Hồ Chí Minh <br>
					  <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> Điện thoại: 0123456789<br>
					</address>
    <p>Coder and Designer <br>BinhTruongCuong</p>
	<h2>&copy; Copyright ©2023 - Design by BinhTruongCuong --</h2>
	<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 text-right">
					<a href="#"><img src="image\facebook.png" alt=""></a>
					<a href="#"><img src="image\twitter.png" alt=""></a>
					<a href="#"><img src="image\google.png" alt=""></a>
				</div>
	</footer>
</body>
</html>