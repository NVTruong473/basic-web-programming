<?php
$title = 'Product Page';
include_once('layouts/header.php');
require_once('db/dbhelper.php');
require_once('utils/utility.php');

$productList = executeResult('select * from products');
?>
<!-- body START -->
<div class="row">
<?php
foreach ($productList as $item) {
	?>
	<div class="col-md-3" style="border: solid 2px #e9e6e6; margin-top: 10px;">
			<a href="detail.php?id=<?php echo $item['id']; ?>"><img src="<?php echo $item['thumbnail'];?>" style="width: 100%"></a>
			<a href="detail.php?id=<?php echo $item['id']; ?>"><p style="font-size: 26px;"><?php echo $item['title']; ?></p></a>
			<p style="font-size: 26px; color: red"><?php echo number_format($item['price'], 0, '', '.'); ?> VND</p>
		</div>
	<?php
}
?>
</div>
<!-- body END -->
<?php
include_once('layouts/footer.php');
?>