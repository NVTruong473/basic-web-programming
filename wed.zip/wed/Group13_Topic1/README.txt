Chúng em đã đưa trang web lên domain: binhcuongtruong.com
B1. Tạo database (CSDL)
create database products_detail

B2. Bảo đảm localhost đã trỏ vào database products_detail và tạo bảng theo lệnh sql để chứa dữ liệu
create table products (
	id int primary key auto_increment,
	title varchar(250) not null,
	thumbnail varchar(500),
	content longtext,
	price float,
	created_at datetime,
	updated_at datetime
);

create table orders (
	id int primary key auto_increment,
	fullname varchar(100),
	phone_number varchar(20),
	email varchar(200),
	address varchar(200),
	order_date datetime
);

create table order_details (
	id int primary key auto_increment,
	order_id int references orders (id),
	product_id int references products (id),
	num int,
	price float
);

B3. Chèn dữ liệu có sẵn trong file sql.txt


INSERT INTO `products`(
    `id`,
    `title`,
    `thumbnail`,
    `content`,
    `price`,
    `created_at`,
    `updated_at`
)
VALUES(
    1,
    'Nike AAA',
    'image/product1.jpg',
    NULL,
    2500000,
    NULL,
    NULL
),
(
    2,
    'Nike AAA',
    'image/product2.jpg',
    NULL,
    2000000,
    NULL,
    NULL
),
(
    3,
    'Nike AAA',
    'image/product3.jpg',
    NULL,
    1700000,
    NULL,
    NULL
),
(
    4,
    'Nike AAA',
    'image/product4.jpg',
    NULL,
    3500000,
    NULL,
    NULL
),
(
    5,
    'Nike air max',
    'image/product5.jpg',
    NULL,
    3000000,
    NULL,
    NULL
),
(
    6,
    'Nike air max 3',
    'image/product6.jpg',
    NULL,
    2600000,
    NULL,
    NULL
),
(
    7,
    'Nike royal 11',
    'image/product7.jpg',
    NULL,
    2450000,
    NULL,
    NULL
),
(
    8,
    'Nike jordan',
    'image/product8.jpg',
    NULL,
    2400000,
    NULL,
    NULL
),
(
    9,
    'Nike low',
    'image/product9.jpg',
    NULL,
    2100000,
    NULL,
    NULL
),
(
    10,
    'Nike gray',
    'image/product10.jpg',
    NULL,
    5000000,
    NULL,
    NULL
),
(
    11,
    'Air max Nike',
    'image/product11.jpg',
    NULL,
    5750000,
    NULL,
    NULL
),
(
    12,
    'Nike Black',
    'image/product12.jpg',
    NULL,
    4500000,
    NULL,
    NULL
)

==> Thành công add database vào trang web sẽ được hiển thị đầy đủ
